
from flask import Flask, request
from json import load
app = Flask(__name__)
from os import listdir
    


@app.get('/stats/')
def stats():
    try:
        channel = request.headers["Nightbot-Channel"]
        user = request.headers["Nightbot-User"]
    except KeyError:
        return "Not able to auth"
    
    channel_id = channel.get("providerId")
    user_id = user.get("providerId")
    if channel_id not in listdir():
        return "Channel not cached (yet)"
    with open(f"./{channel_id}/first_ever.json", mode="r", encoding="utf-8") as f:
        data = load(f)
    with open(f"./{channel_id}/person_wise/{user_id}.txt", mode="r", encoding="utf-8") as f:
        count = len(f.readlines())
    return f"{user['name']} You have made {count} messages, You First interacted with us on a stream that was {user['ago']}, here -> {user['link']}"

app.run(port=5012)